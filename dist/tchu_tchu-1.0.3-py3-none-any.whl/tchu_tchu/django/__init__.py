"""Django integration utilities for tchu-tchu."""

from tchu_tchu.django.decorators import auto_publish

__all__ = ["auto_publish"]
